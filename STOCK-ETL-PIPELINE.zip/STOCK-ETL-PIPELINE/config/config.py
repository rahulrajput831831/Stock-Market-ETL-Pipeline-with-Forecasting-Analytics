DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "stock_pipeline"
}

TICKER = "AAPL"