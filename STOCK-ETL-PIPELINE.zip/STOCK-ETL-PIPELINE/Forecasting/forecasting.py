import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="YOUR_PASSWORD",
    database="stock_pipeline"
)

query = "SELECT date, close FROM stock_prices ORDER BY date"

df = pd.read_sql(query, connection)

df["date"] = pd.to_datetime(df["date"])

df["moving_avg"] = df["close"].rolling(window=5).mean()

print(df.tail())

plt.plot(df["date"], df["close"], label="Actual Price")
plt.plot(df["date"], df["moving_avg"], label="Moving Average")

plt.legend()
plt.show()