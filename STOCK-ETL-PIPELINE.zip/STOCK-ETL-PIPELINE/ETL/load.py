import sys
import os
import mysql.connector
import pandas as pd


sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import DB_CONFIG


def get_last_loaded_date(cursor):

    query = "SELECT MAX(date) FROM stock_prices"
    cursor.execute(query)

    result = cursor.fetchone()

    return result[0]


def load_data(df):

    connection = mysql.connector.connect(**DB_CONFIG)
    cursor = connection.cursor()

    # get last date already in DB
    last_date = get_last_loaded_date(cursor)

    if last_date is not None:
        last_date = pd.to_datetime(last_date)
        df = df[df["date"] > last_date]

    # if no new rows
    if df.empty:
        print("No new data to load")
        cursor.close()
        connection.close()
        return

    insert_query = """
    INSERT INTO stock_prices (date, open, high, low, close, volume)
    VALUES (%s,%s,%s,%s,%s,%s)
    """

    values = list(
        df[["date", "open", "high", "low", "close", "volume"]]
        .itertuples(index=False, name=None)
    )

    cursor.executemany(insert_query, values)

    connection.commit()

    cursor.close()
    connection.close()

    print(f"{len(values)} new rows inserted into MySQL")