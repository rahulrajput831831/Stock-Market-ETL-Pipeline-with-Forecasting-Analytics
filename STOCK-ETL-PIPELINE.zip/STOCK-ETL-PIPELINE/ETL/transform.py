import os
import pandas as pd

def transform_data(df):

    print("Starting transform step...")

    # column names lowercase
    df.columns = [col.lower() for col in df.columns]

    # convert date column
    df["date"] = pd.to_datetime(df["date"])

    # sort data
    df = df.sort_values("date")

    # check missing values
    print("\nMissing values:")
    print(df.isnull().sum())

    # project root path
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    processed_dir = os.path.join(base_dir, "data", "processed")
    os.makedirs(processed_dir, exist_ok=True)

    processed_path = os.path.join(processed_dir, "stock_clean.csv")

    # save processed data
    df.to_csv(processed_path, index=False)

    print("\nProcessed data saved:", processed_path)

    print("\nTransform step completed")
    print(df.head())

    return df