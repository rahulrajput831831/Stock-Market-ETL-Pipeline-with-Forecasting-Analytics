from extract import extract_data
from transform import transform_data
from validation import validate_data
from load import load_data
from logger import logger


def run_pipeline():

    logger.info("Pipeline started")

    df = extract_data()

    logger.info("Extract step completed")

    validate_data(df)

    logger.info("Validation completed")

    df = transform_data(df)

    logger.info("Transform completed")

    load_data(df)

    logger.info("Load step completed")

    logger.info("Pipeline finished successfully")


if __name__ == "__main__":
    run_pipeline()