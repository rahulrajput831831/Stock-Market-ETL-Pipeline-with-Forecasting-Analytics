import yfinance as yf
from datetime import datetime, timedelta
import os

def extract_data():

    ticker = "AAPL"

    end_date = datetime.today()
    start_date = end_date - timedelta(days=365)

    df = yf.download(ticker, start=start_date, end=end_date)

    df.reset_index(inplace=True)

    # FIX multi-index columns
    df.columns = [col[0] if isinstance(col, tuple) else col for col in df.columns]

    # project root
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    raw_dir = os.path.join(base_dir, "data", "raw")
    os.makedirs(raw_dir, exist_ok=True)

    raw_path = os.path.join(raw_dir, "stock_raw.csv")

    df.to_csv(raw_path, index=False)

    print("Raw data saved:", raw_path)
    print(df.head())

    return df