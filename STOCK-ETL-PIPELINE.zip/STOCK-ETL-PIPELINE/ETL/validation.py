def validate_data(df):

    if df.empty:
        raise ValueError("Dataset is empty")

    if (df["Close"] <= 0).any():
        raise ValueError("Invalid stock price detected")

    print("Validation passed")

    return True