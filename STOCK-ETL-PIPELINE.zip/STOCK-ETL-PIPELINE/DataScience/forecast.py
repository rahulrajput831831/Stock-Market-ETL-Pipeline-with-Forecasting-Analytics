import pandas as pd
import sys
import os
from sqlalchemy import create_engine
from statsmodels.tsa.arima.model import ARIMA

# access config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import DB_CONFIG

engine = create_engine(
    f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)

# read historical prices
query = "SELECT date, close FROM stock_prices ORDER BY date"

df = pd.read_sql(query, engine)

df["date"] = pd.to_datetime(df["date"])

df.set_index("date", inplace=True)
df = df.asfreq("B")

print("Dataset loaded")
print(df.tail())
# build ARIMA model
model = ARIMA(df["close"], order=(5,1,0))

model_fit = model.fit()

print("Model trained successfully")

forecast = model_fit.forecast(steps=7)

print("Next 7 day forecast:")
print(forecast)

future_dates = pd.date_range(
    start=df.index[-1] + pd.Timedelta(days=1),
    periods=7
)

forecast_df = pd.DataFrame({
    "date": future_dates,
    "predicted_price": forecast.values
})

print(forecast_df)

forecast_df.to_sql(
    "stock_future_forecast",
    engine,
    if_exists="replace",
    index=False
)

print("Future forecast saved to database")