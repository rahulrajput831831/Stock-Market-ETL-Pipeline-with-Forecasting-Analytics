import pandas as pd
import mysql.connector
import sys
import os

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error

# access config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import DB_CONFIG
query = "SELECT * FROM stock_features"
from sqlalchemy import create_engine

engine = create_engine(
    f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)

df = pd.read_sql(query, engine)

print("Dataset loaded")

# features
X = df[["lag1","lag2","ma3","ma7","volatility"]]
# target
y = df["close"]

# train test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

# model
model = RandomForestRegressor()

model.fit(X_train, y_train)

print("Model training completed")

# predictions
pred = model.predict(X_test)

# evaluation
mae = mean_absolute_error(y_test, pred)

print("MAE:", mae)
# create prediction dataframe
pred_df = pd.DataFrame({
    "date": df.iloc[-len(pred):]["date"],
    "actual_price": y_test.values,
    "predicted_price": pred
})

print(pred_df.head())
from sqlalchemy import create_engine

engine = create_engine(
    f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)

pred_df.to_sql("stock_predictions", engine, if_exists="replace", index=False)

print("Predictions saved to database table: stock_predictions")