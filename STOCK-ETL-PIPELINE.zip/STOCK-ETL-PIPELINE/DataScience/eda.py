import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt
import seaborn as sns

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="stock_pipeline"
)

query = "SELECT * FROM stock_prices"

df = pd.read_sql(query, connection)

df["date"] = pd.to_datetime(df["date"])

print(df.describe())

# price trend
plt.figure(figsize=(10,5))
plt.plot(df["date"], df["close"])
plt.title("Stock Closing Price Trend")
plt.show()

# correlation
sns.heatmap(df.corr(), annot=True)
plt.show()