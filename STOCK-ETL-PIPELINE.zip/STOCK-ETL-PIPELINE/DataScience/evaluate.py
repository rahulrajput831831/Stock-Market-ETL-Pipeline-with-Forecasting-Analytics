import pandas as pd
from sqlalchemy import create_engine
import matplotlib.pyplot as plt
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import DB_CONFIG

engine = create_engine(
f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)

prices = pd.read_sql("SELECT date, close FROM stock_prices", engine)
forecast = pd.read_sql("SELECT * FROM stock_future_forecast", engine)

prices["date"] = pd.to_datetime(prices["date"])
forecast["date"] = pd.to_datetime(forecast["date"])

plt.figure(figsize=(10,5))

plt.plot(prices["date"], prices["close"], label="Historical Price")
plt.plot(forecast["date"], forecast["predicted_price"], label="Forecast", color="red")

plt.legend()
plt.title("Stock Price Forecast")

plt.show()