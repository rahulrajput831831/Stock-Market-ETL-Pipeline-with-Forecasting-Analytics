import pandas as pd
import mysql.connector
import sys
import os

# access config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import DB_CONFIG

from sqlalchemy import create_engine

engine = create_engine(
    f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)

query = "SELECT date, close FROM stock_prices"

df = pd.read_sql(query, engine)

df["date"] = pd.to_datetime(df["date"])

print("Rows before feature engineering:", len(df))

# ----- Feature Engineering -----

# moving averages
df["ma3"] = df["close"].rolling(3).mean()
df["ma7"] = df["close"].rolling(7).mean()

# volatility
df["volatility"] = df["close"].rolling(7).std()

# lag features
df["lag1"] = df["close"].shift(1)
df["lag2"] = df["close"].shift(2)

print("Rows before dropna:", len(df))

df.dropna(inplace=True)

print("Rows after dropna:", len(df))

print(df.head())

# ----- Save Features to Database -----

df.to_sql("stock_features", engine, if_exists="replace", index=False)

print("Features saved to database table: stock_features")